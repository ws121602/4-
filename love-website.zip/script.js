function checkPassword() {
  const input = document.getElementById('password-input').value;
  const error = document.getElementById('error');
  if (input === '1224') {
    document.getElementById('password-screen').style.display = 'none';
    document.getElementById('main-content').style.display = 'block';
  } else {
    error.textContent = '密码错误，请再试一次！';
  }
}

// Countdown to a special date
const targetDate = new Date('2025-12-24T00:00:00').getTime();
const timer = document.getElementById('timer');
setInterval(() => {
  const now = new Date().getTime();
  const diff = targetDate - now;
  if (diff < 0) {
    timer.textContent = '纪念日到了！💞';
    return;
  }
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  const secs = Math.floor((diff % (1000 * 60)) / 1000);
  timer.textContent = `${days}天 ${hours}小时 ${mins}分 ${secs}秒`;
}, 1000);
